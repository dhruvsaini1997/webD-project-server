import mongoose from "mongoose";
const schema = new mongoose.Schema(
  {
    title: { type: String, unique: true, required: true },
    course: { type: String, required: true },
    status: String,
    points: { type: Number, default: 30 },
    married: { type: Boolean, default: false },
    duedate: { type: Date, default: Date.now },
  },
  { collection: "quizzes" }
);
export default schema;
