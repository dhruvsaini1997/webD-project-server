import { model } from "mongoose";
import * as dao from "./dao.js";
function QuizRoutes(app) {
    const createQuiz = async (req, res) => {
        const quiz = await dao.createQuiz(req.body);
        res.json(quiz);
      };

    const deleteQuiz = async (req, res) => {
        const status = await dao.deleteQuiz(req.params.quizId);
        res.json(status);
    };
      const findAllQuizzes = async (req, res) => {
        const quiz = await dao.findAllQuizzes();
        res.json(quiz);
    };
    const findQuizById = async (req, res) => {
        // const id = req.params.id;
        const { quizId } = req.params;
        console.log(quizId)
        const quiz = await dao.findQuizById(quizId);
        res.json(quiz);
        };
    const findQuizByTitle = async (req, res) => {
        const { title } = req.params;
        const quiz = await dao.findQuizByTitle(title);
        res.json(quiz);
    };
    const updateQuiz = async (req, res) => {
        const { quizId } = req.params;
        const status = await dao.updateQuiz(quizId, req.body);
        const currentQuiz = await dao.findQuizById(quizId);
        req.session['currentQuiz'] = currentQuiz;
        res.json(status);
      };
    
    const account = async (req, res) => {
        res.json(req.session['currentQuiz']);
      };
    
    const findQuizzesByCourse = async (req, res) => {
        const { quizId } = req.params;
        const status = await dao.updateQuiz(quizId, req.body);
        const currentQuiz = await dao.findQuizById(quizId);
        req.session['currentQuiz'] = currentQuiz;
        res.json(status);
      };
      app.get("/api/courses/:id", (req, res) => {
        const { id } = req.params;
        const course = Database.courses
          .find((c) => c._id === id);
        if (!course) {
          res.status(404).send("Course not found");
          return;
        }
        res.send(course);
      });
    
      
    app.post("/api/quiz", createQuiz);
    app.get("/api/quiz", findAllQuizzes);
    app.post("/api/quiz/account", account);
    app.get("/api/quiz/:quizId", findQuizById);
    app.get("/api/quiz/title/:title", findQuizByTitle);
    app.post("/api/quiz", createQuiz);    
    app.put("/api/quiz/:quizId", updateQuiz);
    app.delete("/api/quiz/:quizId", deleteQuiz);
}
export default QuizRoutes;

